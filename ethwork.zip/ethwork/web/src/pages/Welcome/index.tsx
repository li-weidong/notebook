import { PageContainer } from '@ant-design/pro-components';
import { useEmotionCss } from '@ant-design/use-emotion-css';
import { useModel } from '@umijs/max';
import { Card, Layout, Anchor } from 'antd';
import React from 'react';
import './index.less'


const { Header, Content, Footer } = Layout;



const Welcome: React.FC = () => {

  // const classBackgroundImage = useEmotionCss(() => {
  //   return {
  //     display: 'flex',
  //     flexDirection: 'column',
  //     height: '100vh',
  //     overflow: 'auto',
  //     justifyContent: 'center',
  //     width: '100%',
  //     textAlign: 'center',
  //     backgroundImage: `url(${require('./image/mainBackground.jpeg')})`,
  //     backgroundSize: '100% 100%',
  //     color: '#FFFFFF'
  //   };
  // });
  return (
    <Layout style={{ width: '100%' }}>
      <Header style={{ display: 'flex', alignItems: 'center', backgroundColor: 'white', position: 'fixed', width: '100%', justifyContent: 'space-between' }}
      >
        <div>logo</div>
        <Anchor
          style={{ float: 'right',opacity: '0.9' }}
          bounds={20}
          direction="horizontal"
          className=''
          items={[
            {
              key: 'home',
              href: '#home',
              title: '首页',
            },
            {
              key: 'briefIntroduction',
              href: '#briefIntroduction',
              title: '公司简介',
            },
            {
              key: 'business',
              href: '#business',
              title: '业务范围',
            },
            {
              key: 'peculiarity',
              href: '#peculiarity',
              title: '用工特点',
            },
            {
              key: 'businessProcess',
              href: '#businessProcess',
              title: '业务流程',
            },
            {
              key: 'serve',
              href: '#serve',
              title: '服务模式',
            },
            {
              key: 'applicationScenario',
              href: '#applicationScenario',
              title: '应用场景',
            },
            {
              key: 'contactUs',
              href: '#contactUs',
              title: '联系我们',
            },
          ]}
        />
      </Header>
      <Content style={{ padding: '0px 50px 0px 50px'}}>

        <div id='main'>

          <div
            id="home"
            // className={classBackgroundImage}
            style={{display: 'flex',
            flexDirection: 'column',
            height: '100vh',
            overflow: 'auto',
            justifyContent: 'center',
            width: '100%',
            textAlign: 'center'}}
          >
            <p style={{ fontSize: '72px' }}>共享经济智能综合平台 </p>
            <p style={{ fontSize: '20px' }}>您身边的灵活用工、财税优化专家</p>
          </div>

          <div
            id="briefIntroduction"
            style={{
              height: '50vh'


            }}>
            <p className='about-title'>关于爱薪</p>
            <div className='about-content'>
              <span>
                爱薪，是一家政府背景投资设立的“互联网+共享经济”平台经济产 业园，获得海王集团投资入股的基于互联网共享服务的平台型企业，专注于创新企业灵活用 工、财税优化解决方案，并为大型企事业单位提供人力资源合作外包综合服务。
              </span>

            </div>

          </div>
          <div id='business'>

          </div>
          <div id='peculiarity'></div>
          <div id='businessProcess'></div>
          <div id='serve'></div>
          <div id='applicationScenario'></div>
          <div id='contactUs'></div>

        </div>
      </Content>
      <Footer style={{ textAlign: 'center' }}>Ant Design ©2023 Created by Ant UED</Footer>
    </Layout>
  );
};

export default Welcome;
