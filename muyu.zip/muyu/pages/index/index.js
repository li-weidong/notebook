// index.js
// 获取应用实例
const app = getApp()
import {
  randomNumRange,
  formatTime
} from '@utils/util.js'
Page({
  data: {
    userData: {

    },
    music: '05',
    speed: 0.8,
    isVibration: true,
    todayNum: 0,
    total: 0,
    showPerson: false,
    addContext: '',
    opacity: 1,
    addLeft: 0,
    addTop: 0,
    auto: false,
    autoSetInterval: false,
    iconMuyuFontSize: 180,
    radioList: ['01', '02', '03', '04', '05'],
    speedList: [0.8, 1, 1.2, 1.6, 1.8, 2],

    blessList: ['逢凶化吉', '积功累德', '吉祥如意', '无量光明', '吉祥果树', '六时吉祥', '神智洞达', '吉祥自在', '如意吉祥', '福慧双增', '吉神相随', '法喜充满', '所求如意', '大彻大悟', '吉祥如意', '心怀悲悯', '指点迷津', '看破红尘', '四大皆空', '所求如意', '福慧双增', '海纳百川', '离苦得乐', '超尘拔俗', '恶人远离', '万象更新', '法喜充满', '心存感恩', '一尘不染', '逢凶化吉', '好人相逢', '虚怀若谷', '六时吉祥', '吉祥如意', '气若幽兰', '泽如时雨', '澄心清神', '怡然自乐', '凤鸣朝阳', '鹤鸣九皋', '云兴霞蔚', '百川归海', '春和贻荡', '百卉含英', '枕流漱石', '鸢飞鱼跃', '冰壶秋月', '春日暄和', '山浓谷艳', '兰秀菊芳', '鸾翔凤集', '赫日流辉', '龙藏深泉', '松竹含韵', '绿静春深', '兰蕙桂馥', '浮翠流丹', '花意竹情', '五谷丰登', '六畜兴旺', '吉庆有余', '惠风和畅'],
    customWord: '',
  },
  // 自动打击木鱼
  handleClickAuto() {
    const {
      auto,
      autoSetInterval
    } = this.data
    clearInterval(autoSetInterval)
    if (auto === false) {
      this.handleClick()
      const interval = setInterval(() => {
        this.handleClick()
      }, this.data.speed * 1000)
      this.setData({
        auto: true,
        autoSetInterval: interval
      })
    }
    // 如果是ture的时候点击则改成false，并停止敲木鱼
    if (auto === true) {
      this.handleStop()
    }
  },
  handleStop() {
    const {
      auto,
      autoSetInterval
    } = this.data
    clearInterval(autoSetInterval)
    this.setData({
      auto: false
    })
    clearInterval(autoSetInterval)
  },
  // 个人信息
  handleClickPerson() {
    this.setData({
      showPerson: true
    })
  },
  onClose() {
    this.setData({
      showPerson: false
    })
  },
  musicOnChange({
    detail
  }) {
    this.setData({
      'music': detail
    })
    this.playAudio();
  },
  speedOnChange({
    detail
  }) {
    this.setData({
      speed: detail
    })
    this.setData({
      auto: false
    })
    this.handleClickAuto()
  },
  customWordOnChange({
    detail
  }) {
    this.setData({
      customWord: detail
    })
  },
  vibrationOnChange({
    detail
  }) {
    this.setData({
      'isVibration': detail
    })
  },
  // 事件处理函数
  handleClick() {
    this.playAudio();
    this.vibration();
    this.changePosition();
    this.addData();
  },
  // 震动
  vibration() {
    if (this.data.isVibration === true) {
      wx.vibrateShort({
        type: 'medium'
      });
    }

  },
  playAudio() {

    // if (!this.innerAudioContext) {
    this.innerAudioContext = wx.createInnerAudioContext()
    this.innerAudioContext.autoplay = false // 是否自动开始播放，默认为 false
    this.innerAudioContext.loop = false // 是否循环播放，默认为 false
    wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
      obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
      success: function (e) {},
      fail: function (e) {}
    })

    // }
    this.innerAudioContext.src = `/static/${this.data.music}.mp3`
    this.innerAudioContext.play()
    this.innerAudioContext.destroy
    // setTimeout(() => {
    //   this.innerAudioContext.destroy()
    // }, 1000);


  },
  //增加数据，显示隐藏 +1 
  addData() {
    const {
      blessList,
      total = 0,
      todayNum = 0
    } = this.data
    const index = Math.floor((Math.random() * blessList.length))
    this.setData({
      'todayNum': Number(todayNum) + 1,
      'total': Number(total) + 1,
      addContext: this.data.customWord || blessList[index] + '+1',
      iconMuyuFontSize: 160,
      opacity: 1
    })
    setTimeout(() => {
      this.setData({
        addContext: '',
        opacity: 0

      })
    }, 600);
    setTimeout(() => {
      this.setData({
        iconMuyuFontSize: 180
      })
    }, 100);
  },
  changePosition() {
    const top = randomNumRange(-366, 0)
    const left = randomNumRange(0, 350)
    this.setData({
      addTop: top,
      addLeft: left
    })
  },
  isToday(date) {
    let todayDate = new Date().setHours(0, 0, 0, 0); //把今天的日期时分秒设置为00：00：00，返回一个时间戳, 
    // todayDate就是今天00：00：00时刻的时间戳
    let paramsDate = new Date(date).setHours(0, 0, 0, 0); //给new Date()传入时间，并返回传入时间的时间戳
    return todayDate === paramsDate; //时间戳相同时 True 就为今天 
  },


  onShow() {
    try {
      wx.setKeepScreenOn({
        keepScreenOn: true
      })
      let userData = wx.getStorageSync('userData')

      let {
        markDate,
        music = '05',
        isVibration = trie,
        todayNum = 0,
        total = 0,
        customWord,
        speed = 0.8
      } = userData
      if (!markDate) todayNum = 0;
      if (!this.isToday(markDate)) todayNum = 0;
      this.setData({
        userData,
        markDate,
        music,
        isVibration,
        todayNum,
        total,
        customWord,
        speed
      })

    } catch (e) {
      // Do something when catch error
    }
  },
  onHide() {
    try {
      const {
        music,
        isVibration,
        todayNum,
        total,
        customWord,
        speed
      } = this.data
      console.log(this.data)
      const markDate = formatTime(new Date())
      wx.setStorageSync('userData', {
        markDate,
        music,
        isVibration,
        todayNum,
        total,
        customWord,
        speed
      })
    } catch (e) {}
  },
  onLaunch() {
    if (this.innerAudioContext) {
      console.log('onLaunch000')
      this.innerAudioContext.destroy
    }

  },
  onShareAppMessage() {
    const promise = new Promise(resolve => {
      setTimeout(() => {
        resolve({
          title: '木鱼-敲木鱼积功德'
        })
      }, 0)
    })
    return {
      title: '木鱼-敲木鱼积功德',
      path: '/page/index',
      promise
    }
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})